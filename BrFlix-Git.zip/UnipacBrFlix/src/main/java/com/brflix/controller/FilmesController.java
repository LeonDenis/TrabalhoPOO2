package com.brflix.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.brflix.dao.FilmeDao;
import com.brflix.models.Filme;

@RestController
@RequestMapping("/filme")
public class FilmesController {

	@PostMapping("/getFilme")
	public String getFilme() {
		String retorno = "";
		FilmeDao fl = new FilmeDao();
		ArrayList<Filme> filmes = fl.buscarFilme(null);		
		for(Filme filme : filmes) {
			retorno += "<div class=\"col-md-4\">" + 
					"    <div class=\"card\">" + 
					"        <img class=\"card-img-top\" src=\"" + filme.getImagem_url() + "\" alt=\"Imagem Filme\">" + 
					"        <div class=\"card-body\">" + 
					"            <h4 class=\"card-title mb-3\">" + filme.getNome() + "</h4>" + 
					"            <p class=\"card-text\">" + filme.getSinopse() + "</p>" + 
					"        </div>" + 
					"    </div>" + 
					"</div>";
		}
		return retorno;
	}
}

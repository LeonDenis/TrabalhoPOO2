package com.brflix.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/usuario")
public class LoginController {
	
	@GetMapping("/login")
	public String login(@RequestParam("usuario") String usuario, @RequestParam("senha") String senha) {
		// Sua função aqui
		String nome = usuario;
		return "{retorno: 'Logado " + usuario + "'}";
	}

	@GetMapping("/registrar")
	public String registrar(@RequestParam("usuario") String usuario, @RequestParam("senha") String senha,
			@RequestParam("email") String email) {
		// Sua função aqui
		return "{retorno: 'Registrado " + usuario + "'}";
	}
}

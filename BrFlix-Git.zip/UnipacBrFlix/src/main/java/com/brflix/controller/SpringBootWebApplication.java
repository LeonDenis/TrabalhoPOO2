package com.brflix.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.brflix.banco.Banco;

@SpringBootApplication
public class SpringBootWebApplication {

	public static void main(String[] args) throws Exception {
		Banco.getConexao();
		SpringApplication.run(SpringBootWebApplication.class, args);
	}

}
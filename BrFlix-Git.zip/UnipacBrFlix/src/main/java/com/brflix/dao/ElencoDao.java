package com.brflix.dao;


import com.brflix.models.Elenco;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class ElencoDao {
	
	// Efetua a busca por elenco.
	public ArrayList<Elenco> buscarElenco(Elenco elenco) {
		try {
			String sql = "SELECT ID, NOME FROM ELENCO WHERE 1 = 1";
			
			// Filtros
			if(elenco.getNome() != null && elenco.getNome().trim().length() != 0) {
				sql += " AND UPPER(NOME) LIKE TRIM(UPPER('&" + elenco.getNome() + "%'))";
			}
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Elenco> pessoasElenco = new ArrayList<Elenco>();
			while (rs.next()) {
				Elenco novoElenco = new Elenco();
				novoElenco.setId(rs.getInt("ID"));
				novoElenco.setNome(rs.getString("NOME"));
				pessoasElenco.add(novoElenco);
			}
			return pessoasElenco;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Boolean insertElenco(Elenco elenco) {
		try {
			String sql = "INSERT INTO ELENCO (NOME) VALUES (?)";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, elenco.getNome());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Boolean deletarElenco(Elenco elenco) {
		try {
			String sql = "DELETE FROM ELENCO WHERE ID = ? ";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, elenco.getId());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}

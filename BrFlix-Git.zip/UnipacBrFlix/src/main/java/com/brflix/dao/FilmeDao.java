package com.brflix.dao;

import com.brflix.models.Filme;
import com.brflix.models.Genero;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class FilmeDao {

	// Efetua a busca por filmes.
	public ArrayList<Filme> buscarFilme(Filme filme) {
		try {
			String sql = "SELECT F.ID, F.NOME, F.DATA_REGISTRO, F.SINOPSE, F.VIDEO_URL, F.IMAGEM_URL, G.ID GENERO_ID, G.DESCRICAO GENERO FROM FILME F "
					+ "LEFT JOIN GENERO G ON G.ID_FILME = F.ID WHERE 1 = 1";

			// Filtro.
			if (filme != null && filme.getNome() != null && filme.getNome().trim().length() != 0) {
				sql += " AND UPPER(F.NOME) LIKE UPPER(TRIM('%" + filme.getNome() + "%'))";
			}

			if (filme != null && filme.getGenero() != null && filme.getGenero().getDescricao() != null && filme.getGenero().getDescricao().trim().length() != 0) {
				sql += " AND UPPER(G.DESCRICAO) LIKE UPPER(TRIM('%" + filme.getGenero() + "%'))";
			}

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Filme> filmes = new ArrayList<Filme>();
			while (rs.next()) {
				Filme novoFilme = new Filme();
				Genero novoGenero = new Genero();
				novoFilme.setId(rs.getInt("ID"));
				novoFilme.setNome(rs.getString("Nome"));
				novoFilme.setData_registro(rs.getString("Data_Registro"));
				novoFilme.setSinopse(rs.getString("Sinopse"));
				novoFilme.setVideo_url(rs.getString("Video_URL"));
				novoFilme.setImagem_url(rs.getString("Imagem_URL"));
				novoGenero.setId(rs.getInt("GENERO_ID"));
				novoGenero.setId_filme(novoFilme.getId());
				novoGenero.setDescricao(rs.getString("GENERO"));
				novoFilme.setGenero(novoGenero);
				filmes.add(novoFilme);
			}
			return filmes;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Boolean insertFilme(Filme filme) {
		try {
			String sql = "INSERT INTO FILME (NOME, SINOPSE, VIDEO_URL, IMAGEM_URL ) VALUES (?, ?, ?, ?)";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, filme.getNome());
			p.setString(2, filme.getSinopse());
			p.setString(3, filme.getVideo_url());
			p.setString(4, filme.getImagem_url());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// Deletar filme.
	public Boolean deletarFilme(Filme filme) {
		try {
			String sql = "DELETE FROM FILME WHERE ID = ?";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, filme.getId());
			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

}

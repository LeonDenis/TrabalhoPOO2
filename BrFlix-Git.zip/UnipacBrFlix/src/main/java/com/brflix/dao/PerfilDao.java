package com.brflix.dao;

import com.brflix.models.Perfil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class PerfilDao {

	// Busca perfis de usuarios
	public ArrayList<Perfil> buscarPerfil(Perfil perfil) {
		try {
			String sql = "SELECT ID, DESCRICAO FROM PERFIL WHERE 1 = 1";
			
			if(perfil.getId() != null) {
				sql += " AND ID = " + perfil.getId();
			}
			
			if(perfil.getDescricao() != null) {
				sql += " AND UPPER(DESCRICAO) LIKE UPPER(TRIM('%" + perfil.getDescricao() + "%'))";
			}
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Perfil> perfis = new ArrayList<Perfil>();
			while (rs.next()) {
				Perfil novoPerfil = new Perfil();
				novoPerfil.setId(rs.getInt("ID"));
				novoPerfil.setDescricao(rs.getString("DESCRICAO"));
				perfis.add(novoPerfil);
			}
			return perfis;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Insere perfil
	public Boolean insertPerfil(Perfil perfil) {
		try {
			String sql = "INSERT INTO PERFIL (DESCRICAO) VALUES (?)";
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, perfil.getDescricao());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	// Deletar perfil
	public Boolean deletarPerfil(Perfil perfil) {
		try {
			String sql = "DELETE FROM PERFIL WHERE ID = ?";
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, perfil.getId());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}

package com.brflix.models;

public class Comentario {

	private Integer id;

	private String comentario;

	private Integer id_usuario;

	private Integer id_filme;

	public Comentario() {
	}
	
	public Comentario(String comentario, Integer id_usuario, Integer id_filme) {
		this.comentario = comentario;
		this.id_usuario = id_usuario;
		this.id_filme = id_filme;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Integer getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(Integer id_usuario) {
		this.id_usuario = id_usuario;
	}

	public Integer getId_filme() {
		return id_filme;
	}

	public void setId_filme(Integer id_filme) {
		this.id_filme = id_filme;
	}
}

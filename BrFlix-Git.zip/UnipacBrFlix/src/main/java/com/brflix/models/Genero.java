package com.brflix.models;

public class Genero {

	private Integer id;

	private String descricao;

	private Integer id_filme;

	public Genero() {
	}

	public Genero(String descricao, Integer id_filme) {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getId_filme() {
		return id_filme;
	}

	public void setId_filme(Integer id_filme) {
		this.id_filme = id_filme;
	}

}

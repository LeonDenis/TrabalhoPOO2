package com.brflix.banco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Banco {

	// Conexão estática para não ficar criando novas e novas sem necessidade.
	private static Connection conexao;

	// Obtem a conexão.
	public static Connection getConexao() {
		if (conexao == null) {
			iniciaConexao();
		}
		return conexao;
	}

	// Inicia uma conexao nova.
	private static void iniciaConexao() {
		try {
			// Iniciando uma instancia do driver do mysql.
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			System.out.println("Driver carregado.");

			// Conectando com o servidor mysql na máquina local.
			conexao = DriverManager.getConnection("jdbc:mysql://localhost/brflix", "root", "teste321");

			System.out.println("Conexão foi feita.");

		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao carregar o driver.");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao obter conexão.");
			e.printStackTrace();
		} catch (InstantiationException e) {
			System.out.println("Erro ao obter uma nova instancia do driver.");
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.out.println("Erro ao carregar acesso.");
			e.printStackTrace();
		}
	}
	
}

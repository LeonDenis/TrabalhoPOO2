package com.brflix.dao;

import com.brflix.models.Avaliacao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class AvaliacaoDao {

	// Busca avaliacoes de filmes
	public ArrayList<Avaliacao> buscarAvaliacao(Avaliacao avaliacao) {
		try {
			String sql = "SELECT ID, AVALIACAO, ID_FILME, ID_USUARIO " + "FROM AVALIACAO WHERE 1 = 1";

			if(avaliacao.getId_filme() != null) {
				sql += " AND ID_FILME = " + avaliacao.getId_filme();
			}
			
			if(avaliacao.getId_usuario() != null ) {
				sql += " AND ID_USUARIO = " + avaliacao.getId_usuario();
			}
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Avaliacao> avaliacoes = new ArrayList<Avaliacao>();
			while (rs.next()) {
				Avaliacao novaAvaliacao = new Avaliacao();
				novaAvaliacao.setId(rs.getInt("ID"));
				novaAvaliacao.setAvaliacao(rs.getInt("AVALIACAO"));
				novaAvaliacao.setId_usuario(rs.getInt("ID_USUARIO"));
				novaAvaliacao.setId_filme(rs.getInt("ID_FILME"));
				avaliacoes.add(novaAvaliacao);
			}
			return avaliacoes;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Inserir avaliacao
	public Boolean insertAvaliacao(Avaliacao avaliacao) {
		try {
			String sql = "INSERT INTO AVALIACAO (AVALIACAO, ID_USUARIO, ID_FILME) VALUES (?, ?, ?)";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, avaliacao.getAvaliacao());
			p.setInt(2, avaliacao.getId_usuario());
			p.setInt(3, avaliacao.getId_filme());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// Deletar avaliacao
	public Boolean deletarAvaliacao(Avaliacao avaliacao) {
		try {
			String sql = "DELETE FROM AVALIACAO WHERE ID = ?";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, avaliacao.getId());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}

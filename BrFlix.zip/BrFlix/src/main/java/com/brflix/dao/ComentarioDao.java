package com.brflix.dao;

import com.brflix.models.Comentario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class ComentarioDao {

	// Efetua a busca por elenco.
	public ArrayList<Comentario> buscarComentario(Comentario comentario) {
		try {
			String sql = "SELECT COMENTARIO, ID_USUARIO, ID_FILME FROM COMENTARIO WHERE 1 = 1";

			if (comentario.getId_usuario() != null) {
				sql += " AND ID_USUARIO = " + comentario.getId_usuario();
			}
			
			if (comentario.getId_filme() != null) {
				sql += " AND ID_FILME = " + comentario.getId_filme();
			}
			
			if (comentario.getComentario().trim().length() != 0) {
				sql += " AND ID_FILME = " + comentario.getId_filme();
			}

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Comentario> comentarios = new ArrayList<Comentario>();
			while (rs.next()) {
				Comentario novoComentario = new Comentario();
				novoComentario.setId(rs.getInt("ID"));
				novoComentario.setComentario(rs.getString("NOME"));
				novoComentario.setId_usuario(rs.getInt("ID_USUARIO"));
				novoComentario.setId_filme(rs.getInt("ID_FILME"));
				comentarios.add(novoComentario);
			}
			return comentarios;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Inserir comentario
	public Boolean insertComentario(Comentario comentario) {
		try {
			String sql = "INSERT INTO COMENTARIO (COMENTARIO, ID_USUARIO, ID_FILME) VALUES (?, ?, ?)";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, comentario.getComentario());
			p.setInt(2, comentario.getId_usuario());
			p.setInt(3, comentario.getId_filme());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// Deletar comentario
	public Boolean deletarComentario(Comentario comentario) {
		try {
			String sql = "DELETE FROM COMENTARIO WHERE ID = ?";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, comentario.getId());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// Atualiza comentario
	public Boolean updateComentario(Comentario comentario) {
		try {
			String sql = "UPDATE COMENTARIO SET COMENTARIO = ? "
					+ " WHERE ID = ?";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, comentario.getComentario());
			p.setInt(2, comentario.getId());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

}

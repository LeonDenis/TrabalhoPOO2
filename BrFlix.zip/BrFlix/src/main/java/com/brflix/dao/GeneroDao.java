package com.brflix.dao;


import com.brflix.models.Genero;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class GeneroDao {

	// Busca generos de filmes
	public ArrayList<Genero> buscarGenero(Genero genero) {
		try {
			String sql = "SELECT ID, DESCRICAO, ID_FILME FROM GENERO WHERE 1 = 1";
			
			if(genero.getId_filme() != null) {
				sql += " AND ID_FILME = " + genero.getId_filme();
			}
			
			if(genero.getDescricao() != null && genero.getDescricao().trim().length() != 0) {
				sql += " AND UPPER(DESCRICAO) LIKE UPPER(TRIM('%" + genero.getDescricao() + "%'))";
			}

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Genero> generos = new ArrayList<Genero>();
			while (rs.next()) {
				Genero novoGenero = new Genero();
				novoGenero.setId(rs.getInt("ID"));
				novoGenero.setDescricao(rs.getString("DESCRICAO"));
				novoGenero.setId_filme(rs.getInt("ID_FILME"));
				generos.add(novoGenero);
			}
			return generos;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Inserir genero
	public Boolean insertGenero(Genero genero) {
		try {
			String sql = "INSERT INTO GENERO (DESCRICAO, ID_FILME) VALUES (?, ?)";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, genero.getDescricao());
			p.setInt(2, genero.getId_filme());

			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// Deleta o genero
	public Boolean deletarGenero(Genero genero) {
		try {
			String sql = "DELETE FROM GENERO WHERE ID = ?";
			
			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, genero.getId());
			
			p.executeUpdate();
			p.close();
			
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}

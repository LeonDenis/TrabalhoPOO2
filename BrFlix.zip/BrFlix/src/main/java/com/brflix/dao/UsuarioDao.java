package com.brflix.dao;

import com.brflix.models.Perfil;
import com.brflix.models.Usuario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.brflix.banco.Banco;

public class UsuarioDao {

	// Efetua a busca por filmes.
	public ArrayList<Usuario> buscarUsuario(Usuario usuario) {
		try {
			String sql = "SELECT U.ID, U.PRIMEIRO_NOME, U.SOBRENOME,"
					+ "U.EMAIL, U.SENHA, U.DATA_REGISTRO, U.DATA_EXCLUSAO, P.ID IDPERFIL, P.DESCRICAO PERFIL "
					+ "FROM USUARIO U LEFT JOIN USUARIOTEMPERFIL RLC ON RLC.ID_USUARIO = U.ID "
					+ "LEFT JOIN PERFIL P ON P.ID = RLC.ID_PERFIL WHERE 1 = 1";

			// Filtro.
			if (usuario.getPrimeiro_nome().trim().length() != 0) {
				sql += " AND UPPER(U.PRIMEIRO_NOME) LIKE UPPER(TRIM('%" + usuario.getPrimeiro_nome() + "%'))";
			}

			if (usuario.getSobrenome().trim().length() != 0) {
				sql += " AND UPPER(U.SOBRENOME) LIKE UPPER(TRIM('%" + usuario.getSobrenome() + "%'))";
			}

			if (usuario.getPerfil().getDescricao().trim().length() != 0) {
				sql += " AND UPPER(P.DESCRICAO) LIKE UPPER(TRIM('%" + usuario.getPerfil().getDescricao() + "%'))";
			}

			if (usuario.getPerfil().getId() != null) {
				sql += " AND P.ID = " + usuario.getPerfil().getId();
			}

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);
			ResultSet rs = p.executeQuery(sql);
			ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
			while (rs.next()) {
				Usuario novoUsuario = new Usuario();
				Perfil novoPerfil = new Perfil();
				novoUsuario.setId(rs.getInt("ID"));
				novoUsuario.setPrimeiro_nome(rs.getString("PRIMEIRO_NOME"));
				novoUsuario.setSobrenome(rs.getString("SOBRENOME"));
				novoUsuario.setEmail(rs.getString("EMAIL"));
				novoUsuario.setSenha(rs.getString("SENHA"));
				novoUsuario.setData_registro(rs.getString("DATA_REGISTRO"));
				novoUsuario.setData_exclusao(rs.getString("DATA_EXCLUSAO"));
				novoPerfil.setId(rs.getInt("IDPERFIL"));
				novoPerfil.setDescricao(rs.getString("PERFIL"));
				novoUsuario.setPerfil(novoPerfil);
				usuarios.add(novoUsuario);
			}
			return usuarios;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Insere usuário.
	public Boolean insertUsuario(Usuario usuario) {
		try {
			String sql = "INSERT INTO USUARIO (PRIMEIRO_NOME, SOBRENOME, EMAIL, SENHA, DATA_REGISTRO) VALUES (?, ?, ?, ?, Now())";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setString(1, usuario.getPrimeiro_nome());
			p.setString(2, usuario.getSobrenome());
			p.setString(3, usuario.getEmail());
			p.setString(4, usuario.getSenha());

			p.executeUpdate();
			p.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	//Deletar usuário.
	public Boolean deletarUsuario(Usuario usuario) {
		try {
			String sql = "DELETE FROM USUARIO WHERE ID = ?";

			java.sql.PreparedStatement p = Banco.getConexao().prepareStatement(sql);

			p.setInt(1, usuario.getId());
			p.executeUpdate();
			p.close();

			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}

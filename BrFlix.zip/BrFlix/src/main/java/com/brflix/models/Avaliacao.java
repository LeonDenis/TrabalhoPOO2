package com.brflix.models;

public class Avaliacao {

	private Integer id;

	private Integer avaliacao;

	private Integer id_filme;

	private Integer id_usuario;

	public Avaliacao() {
	}

	public Avaliacao(Integer avaliacao, Integer id_filme, Integer id_usuario) {
		this.avaliacao = avaliacao;
		this.id_filme = id_filme;
		this.id_usuario = id_usuario;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(Integer avaliacao) {
		this.avaliacao = avaliacao;
	}

	public Integer getId_filme() {
		return id_filme;
	}

	public void setId_filme(Integer id_filme) {
		this.id_filme = id_filme;
	}

	public Integer getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(Integer id_usuario) {
		this.id_usuario = id_usuario;
	}

}

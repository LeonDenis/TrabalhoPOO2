package com.brflix.models;

public class Filme {

	private Integer id;

	private String nome;

	private String sinopse;

	private String video_url;

	private String imagem_url;
	
	private String data_registro;
	
	private Genero genero;

	public Filme() {
	}
	
	public Filme(String nome, String sinopse, String video_url, String imagem_url) {
		this.nome = nome;
		this.sinopse = sinopse;
		this.video_url = video_url;
		this.imagem_url = imagem_url;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSinopse() {
		return sinopse;
	}

	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}

	public String getVideo_url() {
		return video_url;
	}

	public void setVideo_url(String video_url) {
		this.video_url = video_url;
	}

	public String getImagem_url() {
		return imagem_url;
	}

	public void setImagem_url(String imagem_url) {
		this.imagem_url = imagem_url;
	}

	public String getData_registro() {
		return data_registro;
	}

	public void setData_registro(String data_registro) {
		this.data_registro = data_registro;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}	
	
}

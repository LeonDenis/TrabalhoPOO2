$(function () {
    $.ajax({
        url: '/filme/getFilme',
        type: 'POST',
        success: function (retorno) {
            $('#dvFilmes').html(retorno);
            console.log(retorno);
        },
        error: function (retorno) {
            console.log(retorno);
        }
    });
});
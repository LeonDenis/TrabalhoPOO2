package com.leonix.biblioteca;
import java.util.ArrayList;

public class Biblioteca {

	private static ArrayList<Livro> livros = new ArrayList<Livro>();
	
	private static String nome = "UNIPAC - Biblioteca";
	
	public static void addLivro(Livro livro) throws BibliotecaException {
		livros.add(livro);
	}
	
	public static void addLivros(ArrayList<Livro> livros) {
		for (Livro item : livros) {
			livros.add(item);
		}
	}
	
	public static ArrayList<Livro> getLivros() {
		return livros;
	}
	
	public static String getNome() {
		return nome;
	}
	
}

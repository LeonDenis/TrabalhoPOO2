package com.leonix.biblioteca;

public class BibliotecaException extends Exception {
	
	private static final long serialVersionUID = -8602858003928123671L;
	
}

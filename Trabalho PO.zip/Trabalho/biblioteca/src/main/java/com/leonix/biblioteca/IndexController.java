package com.leonix.biblioteca;

import java.util.ArrayList;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class IndexController {

	@RequestMapping("/")
	public String home() {
		return "index.jsp";
	}

	@RequestMapping("/unipac")
	public String unipac() {
		return "cadastro.jsp";
	}

	@RequestMapping(value = "/iniciarLivros", method = RequestMethod.GET)
	@ResponseBody
	public String iniciarLivros() {
		try {
			
			if (Biblioteca.getLivros().size() == 0) {
				for (int i = 1; i <= 50; i++) {
					Biblioteca.addLivro(new Livro(i, UUID.randomUUID().toString().substring(0, 10)));
				}
			}
			
			return "";

		} catch (BibliotecaException e) {
			return "";
		}
	}

	@RequestMapping(value = "/cadastrar/{nome}/{senha}/{email}", method = RequestMethod.GET)
	@ResponseBody
	public String cadastrar(@PathVariable("nome") String nome, @PathVariable("senha") String senha,
			@PathVariable("email") String email) {

		Usuarios.addUsuario(new Pessoa(nome, senha, email));

		return nome;
	}

	@RequestMapping(value = "/logar/{nome}/{senha}", method = RequestMethod.GET)
	@ResponseBody
	public String logar(@PathVariable("nome") String nome, @PathVariable("senha") String senha) {

		for (Pessoa atual : Usuarios.getPessoas()) {

			if (atual.getNome().equals(nome) && atual.getSenha().equals(senha)) {
				return "Seja bem vindo(a) " + nome + " !";
			}

		}

		return "Usu�rio n�o cadastrado !";
	}

	@RequestMapping(value = "/addLivro/{livro}/{autor}", method = RequestMethod.GET)
	@ResponseBody
	public String addLivro(@PathVariable("livro") String livro, @PathVariable("autor") String autor) {
		try {

			Integer id = 0;

			if (Biblioteca.getLivros().size() == 0) {
				id = 1;
			} else {
				for (Livro atual : Biblioteca.getLivros()) {
					if (atual.getId() >= id) {
						id = (atual.getId() + 1);
					}
				}
			}

			Biblioteca.addLivro(new Livro(id, livro, autor));

			return "Novo livro adicionado com sucesso !";
		} catch (BibliotecaException e) {

			return e.getMessage();

		}
	}

	@RequestMapping(value = "/editarLivro/{livro}/{autor}/{id}", method = RequestMethod.GET)
	@ResponseBody
	public String editarLivro(@PathVariable("livro") String livro, @PathVariable("autor") String autor,
			@PathVariable("id") Integer id) {

		for (Livro atual : Biblioteca.getLivros()) {
			if (atual.getId().equals(id)) {
				String nomeAntigo = atual.getNome();
				String autorAntigo = atual.getAutor();
				atual.setNome(livro);
				atual.setAutor(autor);
				return "Livro " + nomeAntigo + " de autor " + autorAntigo + " alterado para " + livro + " de autor "
						+ autor + " com sucesso !";
			}
		}

		return "Nenhuma altera��o foi feita !";
	}

	@RequestMapping(value = "/removerLivro/{id}", method = RequestMethod.GET)
	@ResponseBody
	public String removerLivro(@PathVariable("id") Integer id) {

		for (Livro atual : Biblioteca.getLivros()) {
			if (atual.getId().equals(id)) {
				String nomeAntigo = atual.getNome();
				String autorAntigo = atual.getAutor();
				Biblioteca.getLivros().remove(atual);
				return "Livro " + nomeAntigo + " de autor " + autorAntigo + " foi exclu�do com sucesso !";
			}
		}

		return "Nenhuma exclus�o foi feita !";
	}

	@RequestMapping(value = "/alugarLivro/{id}/{nome}", method = RequestMethod.GET)
	@ResponseBody
	public String alugarLivro(@PathVariable("id") Integer id, @PathVariable("nome") String nome) {

		String msgAcao = "alugado";

		for (Livro atual : Biblioteca.getLivros()) {
			if (atual.getId().equals(id)) {
				if (atual.getDisponivel().equals(false)) {
					atual.setDisponivel(true);
					msgAcao = "retornado";
					atual.setAlugadoPara("");
				} else {
					atual.setDisponivel(false);
					atual.setAlugadoPara(nome);
				}
				return "Livro " + atual.getNome() + " de autor " + atual.getAutor() + " foi " + msgAcao
						+ " com sucesso !";
			}
		}

		return "Nenhum aluguel foi feito !";
	}

	@RequestMapping(value = "/alugadoPor/{id}", method = RequestMethod.GET)
	@ResponseBody
	public String alugadoPor(@PathVariable("id") Integer id) {

		for (Livro atual : Biblioteca.getLivros()) {
			if (atual.getId().equals(id)) {
				return atual.getAlugadoPara();
			}
		}

		return "Livro dispon�vel !";
	}

	@RequestMapping(value = "/pesquisar/{livro}/{autor}/{disponivel}/{id}", method = RequestMethod.GET)
	@ResponseBody
	public String pesquisar(@PathVariable("livro") String livro, @PathVariable("autor") String autor,
			@PathVariable("disponivel") String disponivel, @PathVariable("id") String id) {

		ArrayList<Livro> livrosRetorno = new ArrayList<Livro>();

		Boolean dispo = false;

		if (livro.trim().equals("0")) {
			livro = "";
		}

		if (autor.trim().equals("0")) {
			autor = "";
		}
		
		if (id.trim().equals("0")) {
			id = "";
		}

		if (disponivel.trim().equals("1")) {
			dispo = true;
		}

		if (disponivel.trim().equals("0")) {
			for (Livro atual : Biblioteca.getLivros()) {
				if (atual.getNome().toLowerCase().contains(livro.toLowerCase())
						&& atual.getAutor().toLowerCase().contains(autor.toLowerCase()) &&
						atual.getId().toString().contains(id)) {
					livrosRetorno.add(atual);
				}
			}
		} else {
			for (Livro atual : Biblioteca.getLivros()) {
				if (atual.getNome().toLowerCase().contains(livro.toLowerCase())
						&& atual.getAutor().toLowerCase().contains(autor.toLowerCase())
						&& atual.getId().toString().contains(id)
						&& atual.getDisponivel().equals(dispo)) {
					livrosRetorno.add(atual);
				}
			}
		}

		return Util.livrosToHtmlRows(livrosRetorno);
	}

}

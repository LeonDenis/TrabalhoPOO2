package com.leonix.biblioteca;

public class Livro {

	private Integer id;

	private String nome;

	private String autor;

	private Boolean disponivel;
	
	private String alugadoPara;

	Livro(Integer id, String nome) {
		this.id = id;
		this.nome = nome;		
		this.autor = "Desconhecido(a)";
		this.disponivel = true;
	}

	Livro(Integer id, String nome, String autor) {
		this.id = id;
		this.nome = nome;
		this.autor = autor;
		this.disponivel = true;
	}

	public Integer getId() {
		return id;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public Boolean getDisponivel() {
		return disponivel;
	}

	public void setDisponivel(Boolean disponivel) {
		this.disponivel = disponivel;
	}

	public String getAlugadoPara() {
		return alugadoPara;
	}

	public void setAlugadoPara(String alugadoPara) {
		this.alugadoPara = alugadoPara;
	}
	
}

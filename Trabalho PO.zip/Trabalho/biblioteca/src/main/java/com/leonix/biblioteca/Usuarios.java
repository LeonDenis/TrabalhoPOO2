package com.leonix.biblioteca;

import java.util.ArrayList;

public class Usuarios {

	private static ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();
	
	public static void addUsuario(Pessoa pessoa) {
		pessoas.add(pessoa);
	}
	
	public static ArrayList<Pessoa> getPessoas() {
		return pessoas;
	}
	
}

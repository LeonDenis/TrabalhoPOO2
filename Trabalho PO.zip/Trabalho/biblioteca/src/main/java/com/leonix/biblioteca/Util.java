package com.leonix.biblioteca;

import java.util.ArrayList;

public class Util {

	public static String livrosToHtmlRows(ArrayList<Livro> livros) {

		String linhas = "";

		for (Livro atual : livros) {
			linhas += "<tr><td class=\"text-center\">" + atual.getId() + "</td>";
			linhas += "<td>" + atual.getNome() + "</td>";
			linhas += "<td>" + atual.getAutor() + "</td>";
			if (atual.getDisponivel()) {
				linhas += "<td class=\"text-center\"><i class=\"fa fa-check\"></i></td>";
			} else {
				linhas += "<td class=\"text-center\"><i class=\"fa fa-times\"></i></td>";
			}
			linhas += "<td class=\"text-center\">\r\n" + 
					"    <button type=\"button\" class=\"btn btn-warning editarLivro\"><i class=\"fa fa-pencil\"></i></button>" + 
					"    <button type=\"button\" class=\"btn btn-danger removerLivro\"><i class=\"fa fa-times\"></i></button>" + 
					"	 <button type=\"button\" class=\"btn btn-info alugarLivro\"><i class=\"fa fa-book\"></i></button>" +
					"</td></tr>";
		}

		return (linhas.trim().length() > 0) ? linhas : "<tr><td colspan=\"5\" class=\"text-center\">Nenhum resultado foi encontrado !</td></tr>";

	}

}
